package com.routon.bluetoothserver;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import android.util.Log;


public class Shell {
	final private String TAG = "Shell";

	/**
	 * 
	 * @param command
	 * @param max_out_length
	 *            <=0:不限输出长度;>0:限制输出长度
	 * @return output 指定max_out_length长度字符串
	 * @throws IOException
	 */
	public String exec_cmd_forground(String command, int max_out_length) throws IOException {
		Log.d(TAG, "exec_cmd_forground command=\"" + command + "\"");
		String output = null;
		Runtime runtime = Runtime.getRuntime();

		Process proc = runtime.exec(new String[] { "sh", "-c", command }); // 这句话就是shell与高级语言间的调用

		// 如果有参数的话可以用另外一个被重载的exec方法
		// 实际上这样执行时启动了一个子进程,它没有父进程的控制台
		// 也就看不到输出,所以我们需要用输出流来得到shell执行后的输出
		if (proc != null) {
			InputStream inputstream = proc.getInputStream();
			if (inputstream != null) {
				InputStreamReader inputstreamreader = new InputStreamReader(inputstream);
				BufferedReader bufferedreader = new BufferedReader(inputstreamreader);

				// read the output
				String line = "";
				StringBuilder sb = new StringBuilder(line);
				int line_num = 0;
				while ((line = bufferedreader.readLine()) != null) {
					if (line_num > 0) {
						line = "\n" + line;
					}
					if (max_out_length > 0) {
						int remain = max_out_length - sb.length();
						if (line.length() < remain) {
							sb.append(line);
							line_num++;
						} else {
							sb.append(line.substring(0, remain));
							break;
						}
					} else {
						sb.append(line);
					}
				}
				output = sb.toString();

				inputstream.close();
			}

			// 使用exec执行不会等执行成功以后才返回,它会立即返回
			// 所以在某些情况下是很要命的(比如复制文件的时候)
			// 使用wairFor()可以等待命令执行完成以后才返回
			try {
				proc.waitFor();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			proc.destroy();
		}

		return output;
	}

	/**
	 * 
	 * @param arg
	 *            : cmd to exec
	 * @param max_out_length
	 *            : -1:get all of log; 0:not get log; >0: get max_out_length
	 *            bytes of log
	 * @return
	 */
	public String routon_client_exec(String filename,String arg, int max_out_length) {
		String result = "";
		String out_temp_filename = "/tmp/routon_client_out.log."+filename;
		//String prefix = "sync;";
		String prefix = "rm -rf " + out_temp_filename + ";";
		String postfix = ";";
		
		//仅在需要日志输出时清理上一次的日志文件
		if (max_out_length != 0) {
			//prefix = "rm -rf " + out_temp_filename + ";";
			postfix = " >" + out_temp_filename + " 2>&1;" + "chmod 777 " + out_temp_filename + ";";
		}
//		String routon_client_arg = "/system/bin/routon_client \"7e8802662e5daf979af0a3a5266bcaa1 " + // prefix
//				prefix + // del temp file
//				arg + // command
//				postfix + // redirect
//				"sync;" + "\""; // postfix
		String routon_client_arg = "/system/bin/routon_client \"7e8802662e5daf979af0a3a5266bcaa1 " + // prefix
				arg + // command
				"\"";

        Log.d(TAG, "==========routon_client_exec exec routon_client_arg "+ routon_client_arg);
		Runtime runtime = Runtime.getRuntime();
		Process process = null;
		InputStream is = null;
		try {
			//process = runtime.exec(new String[] { "sh", "-c", routon_client_arg });
			process = runtime.exec(routon_client_arg);
			try {
				process.waitFor();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (max_out_length != 0) {
				File out_tmp_file = new File(out_temp_filename);
				if (out_tmp_file.exists()) {
					FileInputStream out_temp_file_is = new FileInputStream(out_temp_filename);
					int size = out_temp_file_is.available();
					int byteCount = size;
					int byteOffset = 0;
					if (max_out_length > 0) {
						byteCount = max_out_length <= size ? max_out_length : size;
						byteOffset = size - byteCount;
					}
					byte[] buffer = new byte[byteCount];
					//Log.d(TAG, "byteOffset="+byteOffset+";byteCount="+byteCount);
					out_temp_file_is.skip(byteOffset);
					out_temp_file_is.read(buffer, 0, byteCount);
					out_temp_file_is.close();
					result = new String(buffer);
					out_tmp_file = null;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			Log.d(TAG, "========routon_client_exec =====eeeeeeeeeeerr=" + e.getMessage());
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (process != null) {
				process.destroy();
			}
		}

		//Log.d(TAG, "==========routon_client_exec exec result =["+ result);

		return result;
	}

	public boolean pingbyResult(String ip) {
		boolean res = false;
		String blocks = "";
		Shell shell = new Shell();
		if (shell != null) {
			String cmd = "/system/bin/busybox ping -w 3 -c 3 " + ip;
			blocks = shell.routon_client_exec("ping",cmd, -1);
		}
		if (blocks.contains(" 100% packet loss") || blocks.contains("Network is unreachable")) {
			res = false;
		} else {
			res = true;
		}
		System.out.println("res:" + blocks);
		return res;
	}
	
	public String do_exec(String cmd) {  
        String s = "\n";
        
        BufferedReader in;
        BufferedReader err;
        try {  
            Process p = Runtime.getRuntime().exec(cmd);  
            in = new BufferedReader(  
                                new InputStreamReader(p.getInputStream()));  
            String line = null;
            s += "stdout:\n";
            while ((line = in.readLine()) != null) {  
                s += line + "\n";                 
            }  
            
            err = new BufferedReader(  
                    new InputStreamReader(p.getErrorStream()));
            s += "stderr:\n";
            while ((line = err.readLine()) != null) {  
                s += line + "\n";                 
            }  
            
        } catch (IOException e) {  
            // TODO Auto-generated catch block  
            e.printStackTrace();  
        }  
        Log.v(TAG, "exec : " + cmd + "\nresult : " + s);
        
        return cmd;       
    }  
	
	public boolean do_root_exec(String cmd) {
		boolean ret = true;
		
        String s = "\n";
        
        BufferedReader in;
        BufferedReader err;
        
        try {  
        	String root_cmd = "routon_client 7e8802662e5daf979af0a3a5266bcaa1 " + cmd;
            Process p = Runtime.getRuntime().exec(root_cmd);  
            in = new BufferedReader(  
                                new InputStreamReader(p.getInputStream()));  
            String line = "stdout";  
            while ((line = in.readLine()) != null) {  
                s += line + "\n";                 
            }  
            
            err = new BufferedReader(  
                   new InputStreamReader(p.getErrorStream()));
            line = "error\n";
            while ((line = err.readLine()) != null) {  
               s += line + "\n";                 
            }  
            
        } catch (IOException e) {  
            ret = false;  
            e.printStackTrace();  
        }  
        Log.v(TAG, "exec : " + cmd + "\nresult : " + s);
        
        return ret;       
    }  
}
