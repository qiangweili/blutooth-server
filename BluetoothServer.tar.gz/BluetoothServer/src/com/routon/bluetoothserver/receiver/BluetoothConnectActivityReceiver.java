/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.routon.bluetoothserver.receiver;

import java.io.UnsupportedEncodingException;
import java.util.Locale;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.text.TextUtils;
import android.util.Log;
import android.os.PowerManager;
import android.provider.Settings;

/**
 * BluetoothPairingRequest is a receiver for any Bluetooth pairing request. It
 * checks if the Bluetooth Settings is currently visible and brings up the PIN, the passkey or a
 * confirmation entry dialog. Otherwise it puts a Notification in the status bar, which can
 * be clicked to bring up the Pairing entry dialog.
 */
public final class BluetoothConnectActivityReceiver extends BroadcastReceiver {

    private static final int NOTIFICATION_ID = android.R.drawable.stat_sys_data_bluetooth;

    static final String TAG="BluetoothConnectActivityReceiver";
    static final String action_boot="android.intent.action.BOOT_COMPLETED";
    static final String state_change="android.bluetooth.adapter.action.STATE_CHANGED";
    static Intent startIntent;
    ContentResolver mContentResolver = null;
	boolean mEnableExternal =false;
 
    private String mPairingKey;
    private  BluetoothDevice device;
    private int type;
   
    public  BluetoothConnectActivityReceiver(){
    	super();
		startIntent=new Intent();
		startIntent.setAction("com.routon.bluetoothserverservice");
    }
    

	private final boolean isBluetoothPersistedStateOn() {
        return Settings.Global.getInt(mContentResolver,
                Settings.Global.BLUETOOTH_ON, 0) != 0;
    }
    

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (intent.getAction().equals(action_boot)){
			Log.d(TAG, "wx : myBootReceiver.....");
			startIntent.setPackage(context.getPackageName());
            //context.startService(StartIntent);
            mContentResolver = context.getContentResolver();
            mEnableExternal = isBluetoothPersistedStateOn();
          //  LogManager.d(TAG, "wx : mEnableExternal = %b",mEnableExternal);
            Log.d(TAG, "mEnableExternal= "+mEnableExternal);
            if(!mEnableExternal){
            	startIntent.putExtra("com.routon.bluetoothserverservice.EnableExternal",mEnableExternal);
            	context.startService(startIntent);
            }
        }
        if (intent.getAction().equals(state_change)){
        	Log.d(TAG, "wx : bluetooth state_change.....");
        	int i = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.STATE_OFF);
        	//LogManager.d(TAG, "bluetoothstate is : %d !!!",i);
        	Log.d(TAG,  "bluetoothstate is : " + i);
        	if( i == BluetoothAdapter.STATE_ON){
        		Log.d(TAG, "wx : bluetooth is on.....");
        		startIntent.setPackage(context.getPackageName());
        		startIntent.putExtra("com.routon.bluetoothserverservice.EnableExternal",true);
        		context.startService(startIntent);
        	}
        	else if(i == BluetoothAdapter.STATE_OFF){
        		Log.d(TAG, "wx : bluetooth is off.....restarting ibeacon.....");
        		startIntent.setPackage(context.getPackageName());
        		context.startService(startIntent);
        	}
        }
        if (action.equals(BluetoothDevice.ACTION_PAIRING_REQUEST)) {
        	
        	abortBroadcast();
            // convert broadcast intent into activity intent (same action string)
            device =
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            type = intent.getIntExtra(BluetoothDevice.EXTRA_PAIRING_VARIANT,
                    BluetoothDevice.ERROR);
            
            Log.d("类型", String.valueOf(type));
            if (type == BluetoothDevice.PAIRING_VARIANT_PASSKEY_CONFIRMATION 
                   //||  type == BluetoothDevice.PAIRING_VARIANT_DISPLAY_PASSKEY ||
                  //  type == BluetoothDevice.PAIRING_VARIANT_DISPLAY_PIN
            		) {
                int pairingKey = intent.getIntExtra(BluetoothDevice.EXTRA_PAIRING_KEY,
                        BluetoothDevice.ERROR);
                Log.d("配对码", String.valueOf(pairingKey));
                mPairingKey = String.format(Locale.US, "%06d", pairingKey);
               // pairingIntent.putExtra(BluetoothDevice.EXTRA_PAIRING_KEY, pairingKey);
                
                onPair(null);
                
            }else if(type == BluetoothDevice.PAIRING_VARIANT_PIN){
            	
            }
        }
        else if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(action)) {
            int bondState = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE,
                    BluetoothDevice.ERROR);
            int oldState = intent.getIntExtra(BluetoothDevice.EXTRA_PREVIOUS_BOND_STATE,
                    BluetoothDevice.ERROR);
            if((oldState == BluetoothDevice.BOND_BONDING) &&
                    (bondState == BluetoothDevice.BOND_NONE)) {
                // Remove the notification
                NotificationManager manager = (NotificationManager) context
                    .getSystemService(Context.NOTIFICATION_SERVICE);
                manager.cancel(NOTIFICATION_ID);
            }
           
        }
    }
    
    private void onPair(String value) {
        switch (type) {
            case BluetoothDevice.PAIRING_VARIANT_PIN:
                byte[] pinBytes = convertPinToBytes(value);
                if (pinBytes == null) {
                    return;
                }
                device.setPin(pinBytes);
                break;
/**
            case BluetoothDevice.PAIRING_VARIANT_PASSKEY:
                int passkey = Integer.parseInt(value);
                mDevice.setPasskey(passkey);
                break;
**/
            case BluetoothDevice.PAIRING_VARIANT_PASSKEY_CONFIRMATION:
           // case BluetoothDevice.PAIRING_VARIANT_CONSENT:
            	
            	Log.d("配对  。。。。", "配对");
                device.setPairingConfirmation(true);
                break;
/**
            case BluetoothDevice.PAIRING_VARIANT_DISPLAY_PASSKEY:
            case BluetoothDevice.PAIRING_VARIANT_DISPLAY_PIN:
                // Do nothing.
                break;

            case BluetoothDevice.PAIRING_VARIANT_OOB_CONSENT:
                mDevice.setRemoteOutOfBandData();
                break;
**/
            default:
                Log.e("loggg", "Incorrect pairing type received");
        }
    }
    public static byte[] convertPinToBytes(String pin) {
        if (pin == null) {
            return null;
        }
        byte[] pinBytes;
        try {
            pinBytes = pin.getBytes("UTF-8");
        } catch (UnsupportedEncodingException uee) {
            Log.e("log", "UTF-8 not supported?!?");  // this should not happen
            return null;
        }
        if (pinBytes.length <= 0 || pinBytes.length > 16) {
            return null;
        }
        return pinBytes;
    }

}