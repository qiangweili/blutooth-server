package com.routon.bluetoothserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.UUID;

import android.app.Activity;
import android.app.Instrumentation;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.widget.Toast;

public class BluetoothServerService extends Service {
	
	public static final String SERVICE_NAME ="com.routon.bluetoothserverservice";
	public static final String TAG ="bluetoothserverservice";
	public static final String EXTRA_COMMAND ="command";
	public static final int START_SERVICE = 1 ;
	public static final int RECEIVE_OK = 1 ;
	 private static final String sTag = "BluetoothServerService";  
	 private static final String S_NAME = "BluetoothServerService";  
	 private static final UUID S_UUID = UUID  
	           .fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");  
	 private static  String  NEW_DEVICE_NAME;
	
	 	private BluetoothAdapter mBluetoothAdapter;  
	 	private BluetoothServerSocket mBluetoothServerSocket;
	   private BluetoothSocket mBluetoothSocket;
	   private Thread mServerThread;
	   public Handler mhandler;
	   private OutputStream mOutputStream;
	   private int  code = -1;
	   
	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}


    public enum KEYS {
        KEY_POWER,KEY_MUTE,KEY_HOME,KEY_MENU,KEY_RET,KEY_UP,KEY_DOWN,KEY_LEFT,KEY_RIGHT,KEY_OK,
        KEY_VOLMINUS,KEY_VOLPLUS,KEY_DEL,KEY_SHIFT,KEY_SPACE,
        KEY_NUM0,KEY_NUM1,KEY_NUM2,KEY_NUM3,KEY_NUM4,KEY_NUM5,KEY_NUM6,KEY_NUM7,KEY_NUM8,KEY_NUM9,
        KEY_ALPHA_A,KEY_ALPHA_B,KEY_ALPHA_C,KEY_ALPHA_D,KEY_ALPHA_E,KEY_ALPHA_F,KEY_ALPHA_G,
        KEY_ALPHA_H,KEY_ALPHA_I,KEY_ALPHA_J,KEY_ALPHA_K,KEY_ALPHA_L,KEY_ALPHA_M,KEY_ALPHA_N,KEY_ALPHA_O,KEY_ALPHA_P
        ,KEY_ALPHA_Q,KEY_ALPHA_R,KEY_ALPHA_S,KEY_ALPHA_T,KEY_ALPHA_U,KEY_ALPHA_V,KEY_ALPHA_W,KEY_ALPHA_X,KEY_ALPHA_Y,
        KEY_ALPHA_Z,
        KEY_ALPHA_a,KEY_ALPHA_b,KEY_ALPHA_c,KEY_ALPHA_d,KEY_ALPHA_e,KEY_ALPHA_f,KEY_ALPHA_g,
        KEY_ALPHA_h,KEY_ALPHA_i,KEY_ALPHA_j,KEY_ALPHA_k,KEY_ALPHA_l,KEY_ALPHA_m,KEY_ALPHA_n,KEY_ALPHA_o,KEY_ALPHA_p
        ,KEY_ALPHA_q,KEY_ALPHA_r,KEY_ALPHA_s,KEY_ALPHA_t,KEY_ALPHA_u,KEY_ALPHA_v,KEY_ALPHA_w,KEY_ALPHA_x,KEY_ALPHA_y,
        KEY_ALPHA_z 
    }
	@Override
	public void onCreate() {
		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();  
		modifyBluetoothName();
		mhandler=new Handler(){
        	@Override
        	public void handleMessage(Message msg) {
        		if(msg.what == RECEIVE_OK){
        			final String strMessage = (String ) msg.obj;
        			//Toast.makeText(getApplicationContext(), strMessage, Toast.LENGTH_LONG).show();
        			code = Integer.parseInt(strMessage);// KeyEvent.KEYCODE_A+(strMessage.charAt(0)-'a');

        			simulateKey();
        			
        		}
        	}		
        };
		
	}
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		boolean mEnableExternal=true;
	    	if(intent!=null){
	    		mEnableExternal = intent.getBooleanExtra("com.routon.bluetoothserverservice.EnableExternal", true);
	    		//LogManager.d(TAG, "wx : mEnableExternal = %b",mEnableExternal);
	    	}
	    	if(!mEnableExternal){
	    		if (!mBluetoothAdapter.isEnabled()){
	    			turnOnBluetooth();
	    			return START_STICKY;//等待Bluettoth开启成功的广播
	    		}
	    		
	    	}else{
	    		if (mBluetoothAdapter != null &&  mBluetoothAdapter.isEnabled()) {  
	    
					  new Thread(new Runnable(){
									@Override
									public void run() {
										// TODO Auto-generated method stub
										while(true){
										StartListen();
									}
									}
								
							}).start();
							
				}
				else{
					Log.d(TAG, "请打开蓝牙");
					turnOnBluetooth();
	    			return START_STICKY;//等待Bluettoth开启成功的广播
				}
	    	}	
		  
	    	return START_STICKY;
	}

	private boolean turnOnBluetooth(){
			Log.d(TAG, "本机蓝牙没有开启，开启中。。。！");  
			if(mBluetoothAdapter.enable()==false){
	        	Log.d(TAG, "本机蓝牙开启失败！！！！！");
	        	return false;
	        }
			Log.d(TAG, "本机蓝牙开启成功！！！！");
	    	return true;
	    }
	
	 public void StartListen() {  
	    	
     	// 创建一个无线射频通信(RFCOMM)蓝牙端口  
			Log.d(sTag, "开始监听！！！！！！！！！");
  	    try {
  		   	mBluetoothServerSocket = mBluetoothAdapter  
			            .listenUsingRfcommWithServiceRecord(S_NAME, S_UUID);
  		   	mBluetoothSocket = mBluetoothServerSocket.accept();
  		   	Log.d(sTag, "socket connect success and return!!!!!!!!!");
			mBluetoothServerSocket.close();
  		   	mServerThread = new Thread(new ServerThread(mBluetoothSocket));
  		   	mServerThread.start();
  	   } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
  	   } 
}  
	 
	 public class  ServerThread implements Runnable {
	    	
	    	BluetoothSocket mBluetoothSocket =null;
	 	   private InputStream mInputStream;    
	 	   
	 	   
	    	ServerThread( BluetoothSocket s){
	    		super();
	    		mBluetoothSocket=s;
	    	}
	    	
			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {
					
					if(mBluetoothSocket !=null){
	         		   	mOutputStream = mBluetoothSocket.getOutputStream();
	    				mOutputStream.write("ok".getBytes());
	    				Log.d("dddd", "写入数据");
					}
					mInputStream = mBluetoothSocket.getInputStream();
					Log.d(TAG, "读数据");
					ReceiverData();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
	    	
			   public void ReceiverData() {  
				   byte[] mByte = new byte[1024];  
		           int len = 0;  
			       try {  
			        	  while( (len=mInputStream.read(mByte)) != -1) {
                              int key = mByte[0];
			        		  String Msg = key+"";// new String(mByte,0,mByte.length);
			        		  Message msg=new Message();
			        		  msg.obj=Msg;
			        		  msg.what=RECEIVE_OK;
                              Log.v("ReceiverData",Msg);
			        		  mhandler.sendMessage(msg);
			        	  }
			       } catch (Exception e) {  
			    	   Log.d(TAG, "出现异常");
			           Log.d(sTag, e.getMessage());  
			       }  
			       Log.d("wx", "finish reading socket!!!!");
			    /**  
			     try {
			    	 Log.d(TAG, "关闭socket");
					mBluetoothSocket.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				*/
			   } 
	    }
	 
	 /*
	  * 更改蓝牙名称
	  */

	public void  modifyBluetoothName(){
		String deviceAddress = mBluetoothAdapter.getAddress();
		String deviceName =  mBluetoothAdapter.getName();
		Log.d("设备地址", deviceAddress);
		Log.d("设备名", deviceName);
		NEW_DEVICE_NAME=getProp();
		if(!deviceName.equals(NEW_DEVICE_NAME)){
			mBluetoothAdapter.setName(NEW_DEVICE_NAME);
			Log.d("新设备名", mBluetoothAdapter.getName());
		}
	}
	
	public String getProp(){
		String propName="";
		String new_device_name="";
		 Process process;
		try {
			process = Runtime.getRuntime().exec("getprop ro.build.hwmodel");
			//process = Runtime.getRuntime().exec("getprop ro.build.type");
			InputStreamReader ir = new InputStreamReader(process.getInputStream());  
			 BufferedReader input = new BufferedReader(ir); 
			 if((propName=input.readLine())!=null){
				 if(!propName.equals("")){
					 new_device_name=propName;
				 }else{
					 new_device_name="routon";
				 }
				
			 }else{
				 new_device_name="routon";
			 }
			 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		 
		Log.d(TAG, "属性名称："+new_device_name);
		return new_device_name;
		
	}
	
	public void simulateKey(){
		//模拟按键
		new Thread (new Runnable() {
			public void run() {
				Instrumentation inst=new Instrumentation();
				
                int keyCode = -1;
                boolean shift_st = false;
                if (code>=KEYS.KEY_NUM0.ordinal() && code<=KEYS.KEY_NUM9.ordinal())
                {
                    //num keys

                    keyCode = KeyEvent.KEYCODE_0 +code-KEYS.KEY_NUM0.ordinal();
                }
                if (code>=KEYS.KEY_ALPHA_a.ordinal() && code<=KEYS.KEY_ALPHA_z.ordinal())
                {
                    // a-z
                    keyCode = KeyEvent.KEYCODE_A +code-KEYS.KEY_ALPHA_a.ordinal();
                }
                if (code>=KEYS.KEY_ALPHA_A.ordinal() && code<=KEYS.KEY_ALPHA_Z.ordinal())
                {
                    //A-Z
                    shift_st = true;
                    keyCode = KeyEvent.KEYCODE_A +code-KEYS.KEY_ALPHA_A.ordinal();
                }
                if(code ==KEYS.KEY_DEL .ordinal()){
                	keyCode =KeyEvent.KEYCODE_DEL;
                }
                if(code ==KEYS.KEY_SPACE .ordinal()){
                	keyCode =KeyEvent.KEYCODE_SPACE;
                }
                if(code ==KEYS.KEY_UP .ordinal()){
                	keyCode =KeyEvent.KEYCODE_DPAD_UP;
                }
                if(code ==KEYS.KEY_DOWN .ordinal()){
                	keyCode =KeyEvent.KEYCODE_DPAD_DOWN;
                }
                if(code ==KEYS.KEY_LEFT.ordinal()){
                	keyCode =KeyEvent.KEYCODE_DPAD_LEFT;
                }
                if(code ==KEYS.KEY_RIGHT .ordinal()){
                	keyCode =KeyEvent.KEYCODE_DPAD_RIGHT;
                }
                if(code ==KEYS.KEY_OK.ordinal()){
                	keyCode =KeyEvent.KEYCODE_ENTER;
                }
                if(code ==KEYS.KEY_HOME .ordinal()){
                	keyCode =KeyEvent.KEYCODE_HOME;
                }
                if(code ==KEYS.KEY_MENU .ordinal()){
                	keyCode =KeyEvent.KEYCODE_MENU;
                }
                if(code ==KEYS.KEY_RET.ordinal()){
                	keyCode =KeyEvent.KEYCODE_BACK;
                }
                if(code ==KEYS.KEY_VOLMINUS .ordinal()){
                	keyCode =KeyEvent.KEYCODE_VOLUME_DOWN;
                }
                if(code ==KEYS.KEY_VOLPLUS.ordinal()){
                	keyCode =KeyEvent.KEYCODE_VOLUME_UP;
                }
                if(code ==KEYS.KEY_POWER .ordinal()){
                	keyCode =KeyEvent.KEYCODE_POWER;
                }
                if(code ==KEYS.KEY_MUTE.ordinal()){
                	keyCode =KeyEvent.KEYCODE_VOLUME_MUTE;
                }
                if (shift_st)
                {
                	inst.sendKeySync( new KeyEvent(0,0,KeyEvent.ACTION_DOWN,keyCode,0,KeyEvent.META_SHIFT_ON));
                	inst.sendKeySync( new KeyEvent(0,0,KeyEvent.ACTION_UP,keyCode,0,KeyEvent.META_SHIFT_ON));
                }else{

                	inst.sendKeySync( new KeyEvent(0,0,KeyEvent.ACTION_DOWN,keyCode,0,0));
                	inst.sendKeySync( new KeyEvent(0,0,KeyEvent.ACTION_UP,keyCode,0,0));
                }
			}
		}).start();
	}
	
}
