package com.routon.bluetoothserver;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends Activity {

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);  
		
		//设置蓝牙可见
		Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
		intent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 0);   //据说是可以一直可见
		startActivity(intent);
		
		//开启服务，等待蓝牙配对
        Intent mIntent = new Intent();
        mIntent.putExtra(BluetoothServerService.EXTRA_COMMAND, BluetoothServerService.START_SERVICE);
        mIntent.setAction(BluetoothServerService.SERVICE_NAME);
        mIntent.setPackage(getPackageName());   //android 5.0及以上需要
        startService(mIntent);
        
	}

}
