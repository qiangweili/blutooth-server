/** Automatically generated file. DO NOT MODIFY */
package com.routon.bluetoothserver;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}